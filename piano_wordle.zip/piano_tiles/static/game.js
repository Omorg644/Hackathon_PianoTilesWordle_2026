const NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const LOW = 43;    // G3
const HIGH = 72;   // C6

let S = null;           // game state from the server
let current = [];       // the row being typed (locked notes already filled in)
let selected = 0;       // which cell the next piano key goes into
let busy = false;
const keyStatus = {};   // note -> "green" | "yellow" | "gray"
const RANK = { gray: 1, yellow: 2, green: 3 };

const $ = (id) => document.getElementById(id);
const pitchName = (p) => NAMES[p % 12] + Math.floor(p / 12);
const pitchFreq = (p) => 440 * Math.pow(2, (p - 57) / 12);
const noteFreq = (n) => pitchFreq(parseInt(n.slice(-1), 10) * 12 + NAMES.indexOf(n.slice(0, -1)));

// ---------- sound (keys you press) ----------
let audioCtx = null;
function playTone(note) {
  audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
  const t = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = "triangle";
  osc.frequency.value = noteFreq(note);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(0.35, t + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
  osc.connect(gain).connect(audioCtx.destination);
  osc.start(t);
  osc.stop(t + 0.75);
}

// ---------- piano ----------
function buildPiano() {
  const piano = $("piano");
  piano.innerHTML = "";
  let whiteCount = 0;
  for (let p = LOW; p <= HIGH; p++) if (!NAMES[p % 12].includes("#")) whiteCount++;
  const w = 100 / whiteCount, bw = w * 0.6;
  let whiteIdx = 0;
  for (let p = LOW; p <= HIGH; p++) {
    const name = pitchName(p);
    const key = document.createElement("div");
    key.dataset.note = name;
    key.textContent = name;
    if (name.includes("#")) {
      key.className = "key black";
      key.style.left = `${whiteIdx * w - bw / 2}%`;
      key.style.width = `${bw}%`;
    } else {
      key.className = "key white";
      key.style.left = `${whiteIdx * w}%`;
      key.style.width = `${w}%`;
      whiteIdx++;
    }
    key.addEventListener("pointerdown", (e) => { e.preventDefault(); pressKey(name); });
    piano.appendChild(key);
  }
}

function paintKeys() {
  document.querySelectorAll(".key").forEach((k) => {
    k.classList.remove("green", "yellow", "gray");
    const s = keyStatus[k.dataset.note];
    if (s) k.classList.add(s);
  });
}

function recordKeyColors(guess, colors) {
  guess.forEach((note, i) => {
    const c = colors[i];
    if (!keyStatus[note] || RANK[c] > RANK[keyStatus[note]]) keyStatus[note] = c;
  });
}

// ---------- the guess grid ----------
function firstEmpty() { return current.indexOf(null); }

function render(revealRow = -1) {
  const grid = $("grid");
  grid.innerHTML = "";
  for (let r = 0; r < S.max_attempts; r++) {
    const row = document.createElement("div");
    row.className = "row";
    for (let c = 0; c < S.length; c++) {
      const cell = document.createElement("div");
      cell.className = "cell";
      if (r < S.guesses.length) {
        cell.textContent = S.guesses[r][c];
        cell.classList.add(S.colors[r][c]);
        if (r === revealRow) { cell.classList.add("reveal"); cell.style.setProperty("--i", c); }
      } else if (r === S.guesses.length && !S.finished) {
        const note = current[c];
        const isLocked = S.locked[c] !== null;
        cell.textContent = note || "";
        if (isLocked) cell.classList.add("locked");
        else {
          cell.classList.add("active");
          if (note) cell.classList.add("filled");
          if (c === selected) cell.classList.add("selected");
          cell.addEventListener("click", () => { selected = c; render(); });
        }
      }
      row.appendChild(cell);
    }
    grid.appendChild(row);
  }
  paintKeys();
}

function resetCurrent() {
  current = S.locked.slice();
  const i = firstEmpty();
  selected = i === -1 ? 0 : i;
}

function say(text) { $("message").textContent = text; }

// ---------- actions ----------
function pressKey(note) {
  playTone(note);
  if (!S || S.finished || S.locked[selected] !== null) return;
  current[selected] = note;
  say("");
  const next = current.findIndex((n, i) => n === null && i > selected);
  const any = next !== -1 ? next : firstEmpty();
  if (any !== -1) selected = any;
  render();
}

function deleteNote() {
  if (!S || S.finished) return;
  if (S.locked[selected] === null && current[selected]) { current[selected] = null; render(); return; }
  for (let i = selected - 1; i >= 0; i--) {
    if (S.locked[i] === null) { selected = i; current[i] = null; break; }
  }
  render();
}

async function submitGuess() {
  if (busy || !S || S.finished) return;
  if (current.includes(null)) { say(`Fill all ${S.length} notes first.`); return; }
  busy = true;
  const res = await fetch("/api/guess", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ guess: current }),
  });
  const data = await res.json();
  busy = false;
  if (data.error) { say(data.error); return; }
  S = data;
  const last = S.guesses.length - 1;
  recordKeyColors(S.guesses[last], S.colors[last]);
  resetCurrent();
  say("");
  render(last);
  if (S.finished) setTimeout(showEnd, 900);
}

function shareText() {
  const icons = { green: "🟩", yellow: "🟨", gray: "⬛" };
  const tries = S.solved ? S.guesses.length : "X";
  return `Note Wordle ${tries}/${S.max_attempts}\n` +
    S.colors.map((r) => r.map((c) => icons[c]).join("")).join("\n");
}

function showEnd() {
  $("end").hidden = false;
  $("end-title").textContent = S.solved ? `Solved in ${S.guesses.length}!` : "Out of tries";
  $("end-song").textContent = `The melody was from “${S.song_name}”`;
  $("end-notes").innerHTML = "";
  S.answer.forEach((n) => {
    const d = document.createElement("div");
    d.className = "cell"; d.textContent = n;
    $("end-notes").appendChild(d);
  });
  $("end-score").textContent = `${S.score} points`;
  $("share").textContent = shareText();
  $("end").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

async function newGame() {
  S = await (await fetch("/api/new", { method: "POST" })).json();
  Object.keys(keyStatus).forEach((k) => delete keyStatus[k]);
  $("end").hidden = true;
  say("");
  resetCurrent();
  render();
}

function hear() {
  const audio = new Audio(`/api/audio?t=${Date.now()}`);
  audio.play().catch(() => say("Couldn't play audio. Check your sound settings."));
}

// ---------- start ----------
async function init() {
  buildPiano();
  $("hear").addEventListener("click", hear);
  $("enter").addEventListener("click", submitGuess);
  $("delete").addEventListener("click", deleteNote);
  $("again").addEventListener("click", newGame);
  $("copy").addEventListener("click", () => {
    navigator.clipboard?.writeText(shareText()); say("Result copied!");
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Enter") submitGuess();
    if (e.key === "Backspace") deleteNote();
  });

  S = await (await fetch("/api/state")).json();        // restores the game after a refresh
  S.guesses.forEach((g, i) => recordKeyColors(g, S.colors[i]));
  resetCurrent();
  render();
  if (S.finished) showEnd();
}
init();
