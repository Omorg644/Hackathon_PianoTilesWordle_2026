import os
import uuid
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request, session

from functions import (calculate_score, checking, get_snippet, is_valid_note,
                       load_songs, notes_to_wav)

LENGTH = 5
MAX_ATTEMPTS = 6

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(24)

SONGS = load_songs(Path(__file__).parent / "songs")     # loaded once at startup
GAMES = {}                                              # game id -> that player's game


def new_game():
    song_name, answer = get_snippet(SONGS, LENGTH)
    gid = uuid.uuid4().hex
    GAMES[gid] = {"answer": answer, "song_name": song_name, "guesses": [], "colors": [],
                  "locked": [None] * LENGTH, "solved": False, "finished": False, "score": None}
    session["gid"] = gid
    return GAMES[gid]


def current_game():
    return GAMES.get(session.get("gid")) or new_game()


def public_state(game):
    """What the browser is allowed to see. The answer is only included once the game is over."""
    state = {"length": LENGTH, "max_attempts": MAX_ATTEMPTS, "guesses": game["guesses"],
             "colors": game["colors"], "locked": game["locked"],
             "solved": game["solved"], "finished": game["finished"]}
    if game["finished"]:
        state.update(answer=game["answer"], score=game["score"],
                     song_name=game["song_name"].replace("_", " ").title())
    return state


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/state")
def state():
    return jsonify(public_state(current_game()))


@app.route("/api/new", methods=["POST"])
def new():
    return jsonify(public_state(new_game()))


@app.route("/api/guess", methods=["POST"])
def guess():
    game = current_game()
    if game["finished"]:
        return jsonify(error="This game is over. Start a new one."), 400

    notes = (request.get_json(silent=True) or {}).get("guess")
    if (not isinstance(notes, list) or len(notes) != LENGTH
            or not all(is_valid_note(n) for n in notes)):
        return jsonify(error=f"Enter {LENGTH} valid notes."), 400

    # locked (green) notes can't be changed
    notes = [lock or note for lock, note in zip(game["locked"], notes)]
    colors = checking(notes, game["answer"])
    game["guesses"].append(notes)
    game["colors"].append(colors)
    for i, colour in enumerate(colors):
        if colour == "green":
            game["locked"][i] = notes[i]

    game["solved"] = all(c == "green" for c in colors)
    game["finished"] = game["solved"] or len(game["guesses"]) >= MAX_ATTEMPTS
    if game["finished"]:
        game["score"] = calculate_score(game["solved"], len(game["guesses"]), colors,
                                        game["answer"], MAX_ATTEMPTS)
    return jsonify(public_state(game))


@app.route("/api/audio")
def audio():
    """The secret snippet as a sound file, so the notes themselves never reach the browser."""
    wav = notes_to_wav(current_game()["answer"])
    return Response(wav, mimetype="audio/wav", headers={"Cache-Control": "no-store"})


if __name__ == "__main__":
    app.run(debug=True)
