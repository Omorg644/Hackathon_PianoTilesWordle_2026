#Functions for piano tiles

import csv
from pathlib import Path
import random

def load_songs(folder: str = "songs") -> dict:
    """Read every CSV in the folder. Returns {song_name: [notes in order]}."""
    songs = {}
    for path in Path(folder).glob("*.csv"):
        with open(path, newline="") as f:
            rows = sorted(csv.DictReader(f), key=lambda r: int(r["note_id"]))
        songs[path.stem] = [r["note"].strip() for r in rows]
    return songs

def get_snippet(songs: dict, length: int):
    """Pick a random song and a random run of `length` notes from it."""
    name = random.choice([n for n, notes in songs.items() if len(notes) >= length])
    start = random.randint(0, len(songs[name]) - length)
    return name, songs[name][start:start + length]

def checking(guess: list[str], answer) -> list[str]:
    colors = ["gray"] * len(answer)
    remaining = {}

    # First pass: exact matches
    for i in range(len(answer)):
        if guess[i] == answer[i]:
            colors[i] = "green"
        else:
            note = answer[i]
            remaining[note] = remaining.get(note, 0) + 1

    # Second pass: notes in the wrong position
    for i in range(len(guess)):
        if colors[i] == "green":
            continue

        note = guess[i]
        if remaining.get(note, 0) > 0:
            colors[i] = "yellow"
            remaining[note] -= 1

    return colors

def calculate_score(solved, attempts, colors, snippet, max_attempts=6):
    """Points for a finished round. `colors` is the colour list from the last guess."""
    if solved:
        points = 600 + (max_attempts - attempts) * 100
    else:
        points = colors.count("green") * 50 + colors.count("yellow") * 15

    sharps = sum("#" in n for n in snippet)
    multiplier = 1 + 0.1 * (len(set(snippet)) - 1) + 0.1 * sharps
    return round(points * multiplier)


# ---------- sound for the "Hear the melody" button ----------
import io, math, struct, wave

SEMITONES = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def note_to_freq(note: str) -> float:
    """'A4' -> 440.0 (Hz)."""
    pitch = int(note[-1]) * 12 + SEMITONES[note[0]] + (1 if "#" in note else 0)
    return 440.0 * 2 ** ((pitch - 57) / 12)


def notes_to_wav(notes: list[str], note_seconds: float = 0.55, rate: int = 22050) -> bytes:
    """Turn a list of notes into a WAV sound file (bytes)."""
    samples = []
    for note in notes:
        freq = note_to_freq(note)
        for i in range(int(note_seconds * rate)):
            t = i / rate
            envelope = min(t / 0.01, 1) * math.exp(-4 * t)
            value = (math.sin(2 * math.pi * freq * t)
                     + 0.4 * math.sin(2 * math.pi * freq * 2 * t)
                     + 0.15 * math.sin(2 * math.pi * freq * 3 * t))
            samples.append(int(9000 * envelope * value))
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(b"".join(struct.pack("<h", s) for s in samples))
    return buffer.getvalue()
