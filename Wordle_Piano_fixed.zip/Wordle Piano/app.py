import os
import uuid

from flask import Flask, Response, redirect, render_template, request, session

from functions import (calculate_score, checking, get_snippet, load_songs,
                       notes_to_wav)

LENGTH = 5
MAX_ATTEMPTS = 6
PIANO_NOTES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
COLOR_CLASS = {"green": "correct", "yellow": "present", "gray": "absent"}   # names used in your CSS

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(24)

SONGS = load_songs()          # read the songs folder once, when the server starts
GAMES = {}                    # one game per player, so players don't share an answer


def new_game():
    song_name, snippet = get_snippet(SONGS, LENGTH)
    gid = uuid.uuid4().hex
    GAMES[gid] = {
        "song_name": song_name.replace("_", " ").title(),
        "sound": snippet,                       # real notes with octaves, for playback only
        "answer": [n[:-1] for n in snippet],    # note names only ("F#5" -> "F#"), for checking
        "guesses": [],                          # [{"word": [...], "result": [...]}]
        "locked": [None] * LENGTH,
        "solved": False,
        "game_over": False,
        "note": "",                             # one-time message such as an input error
        "score": 0,
    }
    session["gid"] = gid
    return GAMES[gid]


def get_game():
    return GAMES.get(session.get("gid")) or new_game()


def submit_guess(game, text):
    notes = text.split()
    if len(notes) != LENGTH or not all(n in PIANO_NOTES for n in notes):
        game["note"] = f"Pick all {LENGTH} notes first."
        return

    notes = [lock or n for lock, n in zip(game["locked"], notes)]   # greens stay put
    colors = checking(notes, game["answer"])
    game["guesses"].append({"word": notes, "result": [COLOR_CLASS[c] for c in colors]})
    for i, colour in enumerate(colors):
        if colour == "green":
            game["locked"][i] = notes[i]

    game["solved"] = all(c == "green" for c in colors)
    game["game_over"] = game["solved"] or len(game["guesses"]) >= MAX_ATTEMPTS
    if game["game_over"]:
        game["score"] = calculate_score(game["solved"], len(game["guesses"]), colors,
                                        game["answer"], MAX_ATTEMPTS)


def status_message(game):
    if game["game_over"]:
        song = f'The melody was from "{game["song_name"]}". Score: {game["score"]}'
        if game["solved"]:
            return f"Solved in {len(game['guesses'])}! {song}"
        return f"Out of tries. Answer: {' '.join(game['answer'])}. {song}"
    note, game["note"] = game["note"], ""
    return note or f"Attempt {len(game['guesses']) + 1} of {MAX_ATTEMPTS}"


@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        text = request.form.get("guess", "")
        game = new_game() if text == "NEW" else get_game()
        if text != "NEW" and not game["game_over"]:
            submit_guess(game, text)
        return redirect("/")           # so refreshing doesn't re-send the guess

    game = get_game()
    return render_template(
        "wordle.html",
        message=status_message(game),
        guesses=game["guesses"],
        game_over=game["game_over"],
        locked=game["locked"],
    )


@app.route("/audio")
def audio():
    """The secret melody as a sound file, so the notes never appear in the page."""
    return Response(notes_to_wav(get_game()["sound"]), mimetype="audio/wav",
                    headers={"Cache-Control": "no-store"})


if __name__ == "__main__":
    app.run(debug=True)
